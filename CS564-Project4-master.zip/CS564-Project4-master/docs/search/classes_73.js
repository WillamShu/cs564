var searchData=
[
  ['scannotinitializedexception',['ScanNotInitializedException',['../classbadgerdb_1_1_scan_not_initialized_exception.html',1,'badgerdb']]],
  ['slotinuseexception',['SlotInUseException',['../classbadgerdb_1_1_slot_in_use_exception.html',1,'badgerdb']]]
];
